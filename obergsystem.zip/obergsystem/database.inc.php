<?php
$con=mysqli_connect('localhost','root','','obergsystem');
?>